var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/site-data/route.js")
R.c("server/chunks/[root-of-the-server]__bf9bac88._.js")
R.c("server/chunks/src_lib_docs-sync_ts_03caa04b._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_site-data_route_actions_196f343d.js")
R.m(71805)
module.exports=R.m(71805).exports
