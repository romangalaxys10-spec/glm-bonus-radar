var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sync-docs/route.js")
R.c("server/chunks/[root-of-the-server]__19ad5e38._.js")
R.c("server/chunks/src_lib_docs-sync_ts_03caa04b._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_sync-docs_route_actions_303b9c4f.js")
R.m(62960)
module.exports=R.m(62960).exports
