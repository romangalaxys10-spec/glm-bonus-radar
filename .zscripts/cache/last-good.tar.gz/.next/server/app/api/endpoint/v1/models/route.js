var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/endpoint/v1/models/route.js")
R.c("server/chunks/_d84f4bac._.js")
R.c("server/chunks/[root-of-the-server]__24b8fe1d._.js")
R.c("server/chunks/src_lib_docs-sync_ts_03caa04b._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_endpoint_v1_models_route_actions_3d865631.js")
R.m(58871)
module.exports=R.m(58871).exports
