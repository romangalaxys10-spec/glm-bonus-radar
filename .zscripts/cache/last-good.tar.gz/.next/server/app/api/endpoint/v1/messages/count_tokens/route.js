var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/endpoint/v1/messages/count_tokens/route.js")
R.c("server/chunks/_224a4034._.js")
R.c("server/chunks/[root-of-the-server]__24b8fe1d._.js")
R.c("server/chunks/src_lib_docs-sync_ts_03caa04b._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/ce889_server_app_api_endpoint_v1_messages_count_tokens_route_actions_2128f94a.js")
R.m(46022)
module.exports=R.m(46022).exports
