var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/endpoint/v1/chat/completions/route.js")
R.c("server/chunks/_1686ef7f._.js")
R.c("server/chunks/[root-of-the-server]__24b8fe1d._.js")
R.c("server/chunks/src_lib_docs-sync_ts_03caa04b._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/ce889_server_app_api_endpoint_v1_chat_completions_route_actions_5e41252d.js")
R.m(91867)
module.exports=R.m(91867).exports
