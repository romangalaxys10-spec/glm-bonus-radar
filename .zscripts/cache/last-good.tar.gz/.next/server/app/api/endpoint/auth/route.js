var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/endpoint/auth/route.js")
R.c("server/chunks/[root-of-the-server]__932578a8._.js")
R.c("server/chunks/[root-of-the-server]__24b8fe1d._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/src_lib_docs-sync_ts_03caa04b._.js")
R.c("server/chunks/_next-internal_server_app_api_endpoint_auth_route_actions_f320721e.js")
R.m(17381)
module.exports=R.m(17381).exports
