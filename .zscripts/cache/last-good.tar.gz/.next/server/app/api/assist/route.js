var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/assist/route.js")
R.c("server/chunks/[root-of-the-server]__fc1195ee._.js")
R.c("server/chunks/[root-of-the-server]__24b8fe1d._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/src_lib_docs-sync_ts_03caa04b._.js")
R.c("server/chunks/_next-internal_server_app_api_assist_route_actions_25b08998.js")
R.m(96204)
module.exports=R.m(96204).exports
