var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/announcements/route.js")
R.c("server/chunks/[root-of-the-server]__3d9b723f._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/src_lib_docs-sync_ts_03caa04b._.js")
R.c("server/chunks/_next-internal_server_app_api_announcements_route_actions_d83e3901.js")
R.m(518)
module.exports=R.m(518).exports
