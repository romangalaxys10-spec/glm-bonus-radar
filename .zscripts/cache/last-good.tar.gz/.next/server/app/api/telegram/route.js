var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/telegram/route.js")
R.c("server/chunks/[root-of-the-server]__4400eba6._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_telegram_route_actions_5dc61943.js")
R.m(1595)
module.exports=R.m(1595).exports
