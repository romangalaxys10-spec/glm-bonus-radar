var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/src_9c52dd4f._.js")
R.m(23322)
module.exports=R.m(23322).exports
