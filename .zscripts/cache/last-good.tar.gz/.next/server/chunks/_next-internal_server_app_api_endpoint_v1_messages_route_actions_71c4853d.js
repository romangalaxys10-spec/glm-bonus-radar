module.exports=[8266,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_endpoint_v1_messages_route_actions_71c4853d.js.map