module.exports=[50028,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sync-docs_route_actions_303b9c4f.js.map