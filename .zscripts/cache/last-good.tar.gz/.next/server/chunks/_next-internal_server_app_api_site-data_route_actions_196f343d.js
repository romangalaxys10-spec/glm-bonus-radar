module.exports=[76066,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_site-data_route_actions_196f343d.js.map