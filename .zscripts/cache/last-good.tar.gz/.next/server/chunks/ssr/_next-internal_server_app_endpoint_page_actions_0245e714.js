module.exports=[1130,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_endpoint_page_actions_0245e714.js.map