module.exports=[4911,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_endpoint_v1_models_route_actions_3d865631.js.map