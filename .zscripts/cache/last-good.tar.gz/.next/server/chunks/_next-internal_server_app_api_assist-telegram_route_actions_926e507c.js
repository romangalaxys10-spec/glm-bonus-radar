module.exports=[62432,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_assist-telegram_route_actions_926e507c.js.map