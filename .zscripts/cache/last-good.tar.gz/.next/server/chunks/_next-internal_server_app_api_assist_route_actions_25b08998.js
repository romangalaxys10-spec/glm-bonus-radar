module.exports=[72348,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_assist_route_actions_25b08998.js.map